DELIMITER $$

CREATE PROCEDURE rekap_semua_nilai()
BEGIN
    -- 1. DEKLARASI VARIABEL (Bagian Lilis harus di sini)
    DECLARE v_tugas DECIMAL(5,2);
    DECLARE v_kuis DECIMAL(5,2);
    DECLARE v_uts DECIMAL(5,2);
    DECLARE v_nilai_akhir DECIMAL(5,2);
    
    -- Contoh simulasi pengisian nilai data mentah
    SET v_tugas = 80.00;
    SET v_kuis = 85.00;
    SET v_uts = 90.00;

    -- 2. EKSEKUSI RUMUS (Bagian Lilis yang eror tadi)
    SET v_nilai_akhir = (v_tugas * 0.30) + (v_kuis * 0.30) + (v_uts * 0.40);

    -- Menampilkan hasil kalkulasi ke layar phpMyAdmin
    SELECT v_nilai_akhir AS hasil_nilai_akhir;
END$$

DELIMITER ;