-- 1. PENGAMAN: Menghapus prosedur lama jika sudah terdaftar agar bisa dijalankan berkali-kali
DROP PROCEDURE IF EXISTS rekap_nilai_per_mk;

DELIMITER $$

-- Prosedur menerima parameter Input (p_kode_mk) untuk memfilter mata kuliah secara dinamis
CREATE PROCEDURE rekap_nilai_per_mk(IN p_kode_mk VARCHAR(10))
BEGIN
    -- A. DEKLARASI VARIABEL LOKAL PENAMPUNG DATA (Tugas Lilis)
    DECLARE v_id_nilai INT;
    DECLARE v_nim VARCHAR(20);
    DECLARE v_kode_mk VARCHAR(10);
    DECLARE v_tugas DECIMAL(5,2);
    DECLARE v_kuis DECIMAL(5,2);
    DECLARE v_uts DECIMAL(5,2);
    
    DECLARE v_nilai_akhir DECIMAL(5,2);
    DECLARE v_grade VARCHAR(2);
    DECLARE v_bobot DECIMAL(3,2);
    DECLARE v_status VARCHAR(15);
    
    -- Variabel penanda akhir baris data kursor
    DECLARE done INT DEFAULT FALSE;
    
    -- B. DEKLARASI EXPLICIT CURSOR DENGAN PARAMETER FILTER (Sesuai Ketentuan Poin 8)
    -- Parameter p_kode_mk dari Procedure langsung digunakan di klausa WHERE query kursor
    DECLARE cursor_per_mk CURSOR FOR 
        SELECT id_nilai, nim, kode_mk, nilai_tugas, nilai_kuis, nilai_uts 
        FROM nilai_praktikum
        WHERE kode_mk = p_kode_mk;
        
    -- C. DEKLARASI HANDLER UNTUK MEMUTUS PERULANGAN
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- D. MEMBUKA KURSOR
    OPEN cursor_per_mk;
    
    -- E. PERULANGAN DATA MAHASISWA KHUSUS MK YANG DIPILIH
    rekap_loop: LOOP
        
        FETCH cursor_per_mk INTO v_id_nilai, v_nim, v_kode_mk, v_tugas, v_kuis, v_uts;
        
        IF done THEN
            LEAVE rekap_loop;
        END IF;
        
        -- F. PROSES EKSEKUSI KALKULASI RUMUS (Tugas Lilis)
        SET v_nilai_akhir = (v_tugas * 0.30) + (v_kuis * 0.30) + (v_uts * 0.40);
        
        -- G. PROSES EVALUASI PERCABANGAN GRADE & BOBOT (Tugas Hasriani)
        CASE 
            WHEN v_nilai_akhir BETWEEN 93.00 AND 100.00 THEN SET v_grade = 'A',  v_bobot = 4.00;
            WHEN v_nilai_akhir BETWEEN 85.00 AND 92.99  THEN SET v_grade = 'A-', v_bobot = 3.75;
            WHEN v_nilai_akhir BETWEEN 81.00 AND 84.99  THEN SET v_grade = 'B+', v_bobot = 3.50;
            WHEN v_nilai_akhir BETWEEN 75.00 AND 80.99  THEN SET v_grade = 'B',  v_bobot = 3.25;
            WHEN v_nilai_akhir BETWEEN 71.00 AND 74.99  THEN SET v_grade = 'B-', v_bobot = 3.00;
            WHEN v_nilai_akhir BETWEEN 66.00 AND 70.99  THEN SET v_grade = 'C+', v_bobot = 2.75;
            WHEN v_nilai_akhir BETWEEN 61.00 AND 65.99  THEN SET v_grade = 'C',  v_bobot = 2.50;
            WHEN v_nilai_akhir BETWEEN 56.00 AND 60.99  THEN SET v_grade = 'C-', v_bobot = 2.00;
            WHEN v_nilai_akhir BETWEEN 40.00 AND 55.99  THEN SET v_grade = 'D',  v_bobot = 1.00;
            ELSE SET v_grade = 'E', v_bobot = 0.00;
        END CASE;
        
        -- H. PROSES EVALUASI PERCABANGAN STATUS KELULUSAN (Tugas Hasriani)
        IF v_grade IN ('A', 'A-', 'B+', 'B', 'B-', 'C+', 'C') THEN
            SET v_status = 'LULUS';
        ELSE
            SET v_status = 'TIDAK LULUS';
        END IF;
        
        -- I. MENYIMPAN HASIL REKAP KE TABEL UTAMA (Sesuai Ketentuan Poin 8)
        UPDATE nilai_praktikum 
        SET nilai_akhir = v_nilai_akhir, grade = v_grade, bobot = v_bobot, status_lulus = v_status
        WHERE id_nilai = v_id_nilai;
        
        -- J. PENCATATAN LOG AUDIT TRANSAKSI KE TABEL LOG (Sesuai Ketentuan Poin 8)
        INSERT INTO log_rekap_nilai (nim, kode_mk, nilai_akhir, grade, bobot, status_lulus, keterangan, waktu_proses)
        VALUES (v_nim, v_kode_mk, v_nilai_akhir, v_grade, v_bobot, v_status, CONCAT('Rekap Khusus Mata Kuliah: ', p_kode_mk), NOW());
        
    END LOOP rekap_loop;
    
    -- K. MENUTUP KURSOR
    CLOSE cursor_per_mk;
    
    -- Menampilkan jumlah baris data mata kuliah terkait yang sukses diproses
    SELECT ROW_COUNT() AS jumlah_data_mk_diproses;

END$$

DELIMITER ;