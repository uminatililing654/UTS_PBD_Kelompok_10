DELIMITER $$

-- Membuat prosedur uji coba khusus untuk pembuktian Implicit Cursor
CREATE PROCEDURE test_implicit_cursor_uminati()
BEGIN

    -- 1. Menjalankan perintah manipulasi data (DML) sebagai pemicu
    -- Kita coba update status_lulus secara massal menjadi NULL kembali sebagai simulasi
    UPDATE nilai_praktikum 
    SET status_lulus = NULL;
    
    -- 2. EKSEKUSI IMPLICIT CURSOR (Bagian Tugas Uminati Poin 6)
    -- ROW_COUNT() otomatis menghitung berapa baris tabel nilai_praktikum yang terpengaruh di atas
    SELECT ROW_COUNT() AS jumlah_data_diproses;

END$$

DELIMITER ;