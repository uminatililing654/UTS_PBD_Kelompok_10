DELIMITER $$

-- Kita buat prosedur uji coba khusus untuk struktur perulangan Uminati
CREATE PROCEDURE test_perulangan_uminati()
BEGIN
    -- 1. [MEMINJAM KODE LILIS] Menyiapkan variabel lokal penampung data
    DECLARE v_id_nilai INT;
    DECLARE v_nim VARCHAR(20);
    DECLARE v_kode_mk VARCHAR(10);
    DECLARE v_tugas DECIMAL(5,2);
    DECLARE v_kuis DECIMAL(5,2);
    DECLARE v_uts DECIMAL(5,2);
    
    -- Variabel penanda akhir data kursor
    DECLARE done INT DEFAULT FALSE;
    
    -- 2. [KODE UMINATI] Deklarasi Explicit Cursor mengambil data dari tabel fisik
    DECLARE cursor_total CURSOR FOR 
        SELECT id_nilai, nim, kode_mk, nilai_tugas, nilai_kuis, nilai_uts FROM nilai_praktikum;
        
    -- 3. [KODE UMINATI] Penanganan kondisi jika data di tabel sudah habis membaca
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- 4. [KODE UMINATI] Membuka kursor data
    OPEN cursor_total;
    
    -- 5. [KODE UMINATI] Memulai Perulangan (LOOP)
    rekap_loop: LOOP
        
        -- Mengambil baris data aktif dimasukkan ke variabel lokal
        FETCH cursor_total INTO v_id_nilai, v_nim, v_kode_mk, v_tugas, v_kuis, v_uts;
        
        -- Jika data habis, patahkan perulangan menggunakan LEAVE
        IF done THEN
            LEAVE rekap_loop;
        END IF;
        
        -- (Di sini biasanya posisi tempat perhitungan rumus milik Hasriani/Lilis)
        
    END LOOP rekap_loop;
    
    -- 6. [KODE UMINATI] Menutup kursor setelah selesai digunakan
    CLOSE cursor_total;

    -- Notifikasi sederhana penanda procedure sukses dieksekusi
    SELECT 'Perulangan kursor sukses berjalan tanpa error!' AS Status_Uji_Coba;

END$$

DELIMITER ;