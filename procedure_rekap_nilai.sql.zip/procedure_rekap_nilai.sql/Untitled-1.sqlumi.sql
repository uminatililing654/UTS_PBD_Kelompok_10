-- 1. PENGAMAN: Hapus prosedur lama jika namanya sudah terpakai di database
DROP PROCEDURE IF EXISTS rekap_semua_nilai;

-- 2. Mengubah delimiter bawaan phpMyAdmin agar tidak eror massal
DELIMITER $$

CREATE PROCEDURE rekap_semua_nilai()
BEGIN
    -- =========================================================================
    -- 1. DEKLARASI VARIABEL LOKAL (Tugas Lilis)
    -- =========================================================================
    DECLARE v_id_nilai INT;
    DECLARE v_nim VARCHAR(20);
    DECLARE v_kode_mk VARCHAR(10);
    DECLARE v_tugas DECIMAL(5,2);
    DECLARE v_kuis DECIMAL(5,2);
    DECLARE v_uts DECIMAL(5,2);
    
    DECLARE v_nilai_akhir DECIMAL(5,2);
    DECLARE v_grade VARCHAR(2);
    DECLARE v_bobot DECIMAL(3,2);
    DECLARE v_status VARCHAR(15);
    
    DECLARE done INT DEFAULT FALSE;
    
    -- =========================================================================
    -- 2. DEKLARASI EXPLICIT CURSOR & HANDLER (Tugas Uminati)
    -- =========================================================================
    DECLARE cursor_total CURSOR FOR 
        SELECT id_nilai, nim, kode_mk, nilai_tugas, nilai_kuis, nilai_uts FROM nilai_praktikum;
        
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cursor_total;
    
    -- =========================================================================
    -- 3. PERULANGAN DATA (Tugas Uminati)
    -- =========================================================================
    rekap_loop: LOOP
        
        FETCH cursor_total INTO v_id_nilai, v_nim, v_kode_mk, v_tugas, v_kuis, v_uts;
        
        IF done THEN
            LEAVE rekap_loop;
        END IF;
        
        -- =========================================================================
        -- 4. PERHITUNGAN RUMUS NILAI AKHIR (Tugas Lilis)
        -- =========================================================================
        SET v_nilai_akhir = (v_tugas * 0.30) + (v_kuis * 0.30) + (v_uts * 0.40);
        
        -- =========================================================================
        -- 5. PERCABANGAN GRADE, BOBOT & STATUS (Tugas Hasriani)
        -- =========================================================================
        CASE 
            WHEN v_nilai_akhir BETWEEN 93.00 AND 100.00 THEN SET v_grade = 'A',  v_bobot = 4.00;
            WHEN v_nilai_akhir BETWEEN 85.00 AND 92.99  THEN SET v_grade = 'A-', v_bobot = 3.75;
            WHEN v_nilai_akhir BETWEEN 81.00 AND 84.99  THEN SET v_grade = 'B+', v_bobot = 3.50;
            WHEN v_nilai_akhir BETWEEN 75.00 AND 80.99  THEN SET v_grade = 'B',  v_bobot = 3.25;
            WHEN v_nilai_akhir BETWEEN 71.00 AND 74.99  THEN SET v_grade = 'B-', v_bobot = 3.00;
            WHEN v_nilai_akhir BETWEEN 66.00 AND 70.99  THEN SET v_grade = 'C+', v_bobot = 2.75;
            WHEN v_nilai_akhir BETWEEN 61.00 AND 65.99  THEN SET v_grade = 'C',  v_bobot = 2.50;
            WHEN v_nilai_akhir BETWEEN 56.00 AND 60.99  THEN SET v_grade = 'C-', v_bobot = 2.00;
            WHEN v_nilai_akhir BETWEEN 40.00 AND 55.99  THEN SET v_grade = 'D',  v_bobot = 1.00;
            ELSE SET v_grade = 'E', v_bobot = 0.00;
        END CASE;
        
        IF v_grade IN ('A', 'A-', 'B+', 'B', 'B-', 'C+', 'C') THEN
            SET v_status = 'LULUS';
        ELSE
            SET v_status = 'TIDAK LULUS';
        END IF;
        
        -- =========================================================================
        -- 6. UPDATE TABEL UTAMA & LOGGING DATA (Tugas Uminati)
        -- =========================================================================
        UPDATE nilai_praktikum 
        SET nilai_akhir = v_nilai_akhir, grade = v_grade, bobot = v_bobot, status_lulus = v_status
        WHERE id_nilai = v_id_nilai;
        
        INSERT INTO log_rekap_nilai (nim, kode_mk, nilai_akhir, grade, bobot, status_lulus, keterangan, waktu_proses)
        VALUES (v_nim, v_kode_mk, v_nilai_akhir, v_grade, v_bobot, v_status, 'Proses Rekapitulasi Otomatis Sukses', NOW());
        
    END LOOP rekap_loop;
    
    CLOSE cursor_total;
    
    -- =========================================================================
    -- 7. IMPLICIT CURSOR ROW_COUNT (Tugas Uminati)
    -- =========================================================================
    SELECT ROW_COUNT() AS jumlah_data_diproses;

END$$

DELIMITER ;