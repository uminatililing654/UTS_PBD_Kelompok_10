DELIMITER $$

-- Kita buat prosedur sementara untuk mengetes logika Hasriani
CREATE PROCEDURE test_logika_hasriani()
BEGIN
    -- 1. Menyiapkan variabel lokal pendukung (Gabungan dengan Lilis)
    DECLARE v_nilai_akhir DECIMAL(5,2);
    DECLARE v_grade VARCHAR(2);
    DECLARE v_bobot DECIMAL(3,2);
    DECLARE v_status VARCHAR(15);
    
    -- Ubah angka di bawah ini untuk menguji grade lainnya (Contoh: 85.50)
    SET v_nilai_akhir = 85.50; 

    -- 2. Logika Percabangan Hasriani
    CASE 
        WHEN v_nilai_akhir BETWEEN 93.00 AND 100.00 THEN SET v_grade = 'A',  v_bobot = 4.00;
        WHEN v_nilai_akhir BETWEEN 85.00 AND 92.99  THEN SET v_grade = 'A-', v_bobot = 3.75;
        WHEN v_nilai_akhir BETWEEN 81.00 AND 84.99  THEN SET v_grade = 'B+', v_bobot = 3.50;
        WHEN v_nilai_akhir BETWEEN 75.00 AND 80.99  THEN SET v_grade = 'B',  v_bobot = 3.25;
        WHEN v_nilai_akhir BETWEEN 71.00 AND 74.99  THEN SET v_grade = 'B-', v_bobot = 3.00;
        WHEN v_nilai_akhir BETWEEN 66.00 AND 70.99  THEN SET v_grade = 'C+', v_bobot = 2.75;
        WHEN v_nilai_akhir BETWEEN 61.00 AND 65.99  THEN SET v_grade = 'C',  v_bobot = 2.50;
        WHEN v_nilai_akhir BETWEEN 56.00 AND 60.99  THEN SET v_grade = 'C-', v_bobot = 2.00;
        WHEN v_nilai_akhir BETWEEN 40.00 AND 55.99  THEN SET v_grade = 'D',  v_bobot = 1.00;
        ELSE SET v_grade = 'E', v_bobot = 0.00;
    END CASE;

    IF v_grade IN ('A', 'A-', 'B+', 'B', 'B-', 'C+', 'C') THEN
        SET v_status = 'LULUS';
    ELSE
        SET v_status = 'TIDAK LULUS';
    END IF;

    -- 3. Menampilkan hasil tes ke layar phpMyAdmin
    SELECT v_nilai_akhir AS Nilai, v_grade AS Grade, v_bobot AS Bobot, v_status AS Status;

END$$

DELIMITER ;